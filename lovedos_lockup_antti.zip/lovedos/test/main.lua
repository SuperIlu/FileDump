
function love.load()
	snd1 = love.audio.newSource("toot.wav")
	snd2 = love.audio.newSource("boost.wav")
	image = love.graphics.newImage("ball.png")
end

function love.draw()
	love.graphics.print('Hello World!', 20, 30)
  
	if love.mouse.isDown(1) then
		love.graphics.print("Duration: " .. snd1:getDuration(), 20, 50)
		snd1:play()
	end

	if love.mouse.isDown(2) then
		love.graphics.print("Duration: " .. snd2:getDuration(), 20, 50)
		snd2:play()
	end

	love.graphics.draw(image, 100, 100)

	function love.keypressed(key)
		if key == "escape" then
	  		love.event.quit()
		end
	end
end
